<div style="background-color: #f3f4f6; padding: 10px; border-radius: 5px; text-align: center;">
    <strong>الإجمالي بالحروف:</strong>
    <span style="color: #2563eb; font-weight: bold;">{{ $state }}</span>
</div>
