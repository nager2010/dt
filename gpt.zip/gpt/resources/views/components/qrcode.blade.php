<div>
{!! QrCode::size(100)->generate($getState()) !!}
</div>
