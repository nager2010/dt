<?php

namespace App\Filament\Resources\LicenseRequestResource\Pages;

use App\Filament\Resources\LicenseRequestResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLicenseRequest extends CreateRecord
{
    protected static string $resource = LicenseRequestResource::class;
}
