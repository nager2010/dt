<?php

namespace App\Filament\Resources\ExpiredLicensesResource\Pages;

use App\Filament\Resources\ExpiredLicensesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateExpiredLicenses extends CreateRecord
{
    protected static string $resource = ExpiredLicensesResource::class;
}
