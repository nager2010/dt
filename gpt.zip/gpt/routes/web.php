<?php
//use App\Filament\Resources\IssuingLicenseResource\Pages\CreateIssuingLicense;
//
//Route::get('/issuing-licenses/create', CreateIssuingLicense::class)
//    ->name('issuing-licenses.create-public')
//    ->withoutMiddleware('auth'); // تعطيل المصادقة
